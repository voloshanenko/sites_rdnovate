//Document Link Overrides
CKEDITOR.plugins.setLang('jabout','en',
{
	jabout :
	{
		title		: 'About JoomlaCK Editor',
		dlgTitle	: 'About JoomlaCK Editor',
		moreInfo	: 'For licensing information please visit our web site:',
		copy		: 'Copyright &copy; $1. All rights reserved.'
	}
});
