//JtreeLink plugin Language Settings
CKEDITOR.plugins.setLang('jtreelink','es',
{
	jtreelink :
	{
		toolbar			: 'JTree Link\u200b',
		menu			: 'Editar treeLink',
		title			: 'JTreeLink',
		info			: 'Enlace Info',
		advanced		: 'Avanzado',
		target			: 'Objetivo',
		targetFrameName	: 'Objetivo nombre de marco',
		targetPopupName	: 'Nombre de la ventana emergente',
		targetFrame		: 'LightBox/<frame>',
		targetPopup		: '<Ventana emergente>',
		targetFrameName	: 'Objetivo nombre de marco',
		targetPopupName	: 'Nombre de la ventana emergente',
		popupFeatures	: 'Caracter�sticas de Ventana emergente',
		popupResizable	: 'De tama�o variable',
		popupStatusBar	: 'La barra de estado',
		popupLocationBar: 'Localizaci�n Bar',
		popupToolbar	: 'Barra de herramientas',
		popupMenuBar	: 'Barra de men�',
		popupFullScreen	: 'Pantalla completa (IE)',
		popupScrollBars	: 'Barras de desplazamiento',
		popupDependent	: 'Dependiente (Netscape)',
		popupWidth		: 'Ancho',
		popupLeft		: 'Posici�n a la izquierda',
		popupHeight		: 'Altura',
		popupTop		: 'Subir',
		id				: 'Id',
		langDir			: 'Idioma Direcci�n',
		langDirLTR		: 'De izquierda a derecha (LTR)',
		langDirRTL		: 'De derecha a izquierda (RTL)',
		acccessKey		: 'Access Key',
		name			: 'Nombre',
		langCode		: 'C�digo de idioma',
		tabIndex		: 'Ficha �ndice',
		advisoryTitle	: 'T�tulo de asesoramiento',
		advisoryContentType	: 'Tipo de Contenido',
		cssClasses		: 'Las clases de hojas de estilo',
		charset			: 'Recursos Codificaci�n del',
		styles			: 'Estilo'
	}
});

		