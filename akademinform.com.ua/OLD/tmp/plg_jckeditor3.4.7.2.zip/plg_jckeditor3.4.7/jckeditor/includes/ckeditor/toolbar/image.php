<?php
class JCKImage extends JCKToolbar
{
	// row 1
	var $ImageManager = 1;
	var $Image;
}