<?php
class JCKBasic extends JCKToolbar
{
	
	//row 1
	var $Cut = 1;
	var $Copy;
	var $Paste;
	var $PasteText;
	var $PasteFromWord;
	var $SelectAll;
	var $sep_1;
	var $SpellChecker;
	var $Scayt;
	
	//row 2
	var $Undo = 2;
	var $Redo;
	var $RemoveFormat;
	var $sep_2;
	var $Find;
	var $Replace;
	var $sep_3;
	
	//row 3
	var $Bold = 3;
	var $Italic;
	var $Underline;
	
	//row 4
	var $NumberedList = 4;
	var $BulletedList;
	var $sep_4;
	var $Outdent;
	var $Indent;
	
	//row 5
	var $JustifyLeft = 5;
	var $JustifyCenter;
	var $JustifyRight;
	var $JustifyBlock;
	
	//row 6
	var $JTreeLink = 6;
	var $Link;
	var $Unlink;
	
	//row 7
	var $Image= 7;
	var $Table;
	
	//row 8
	var $Format = 8;
	var $ShowBlocks;
	
	//row 9
	var $Maximize = 9;
	var $Preview;
	var $sep_6;
	var $About;
	
}