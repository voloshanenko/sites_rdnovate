Using another background for business cards in SOBI:

To use another background for your business cards in SOBI rename the corresponding card
to "visitenkarte.gif" and copy it to the include directory of SOBI.

Don't forget to adopt the font colors in com_sobi.css.

Have fun.
Sigrid

info@sigsiu.net
http://www.sigsiu.net


